# open-code-with-content

使用URL scheme打开vscode并打开带有内容的新文件
